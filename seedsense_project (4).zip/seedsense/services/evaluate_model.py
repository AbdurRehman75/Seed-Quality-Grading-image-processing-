"""
SeedSense — Model Evaluator
=============================
University of Agriculture Faisalabad · BS Software Engineering FYP 2026

Produces:
  • Classification report (precision / recall / f1 / accuracy)
  • Confusion matrix PNG
  • Accuracy / loss learning curve PNG  (re-generated from saved history)
  • {seed_type}_metrics.json  (consumed by Flask /training dashboard)

Usage:
  python services/evaluate_model.py --seed_type all
"""

import os
import sys
import json
import argparse
import logging
from pathlib import Path

import numpy as np

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("evaluate_model")

# ── Paths ──────────────────────────────────────────────────────────────────────
APP_DIR     = Path(__file__).resolve().parent.parent
DATASET_DIR = APP_DIR / "dataset"
MODELS_DIR  = APP_DIR / "models"
REPORTS_DIR = APP_DIR / "training_reports"
REPORTS_DIR.mkdir(exist_ok=True)

SEED_TYPES = ["wheat", "rice", "corn"]
GRADES     = ["A", "B", "C"]
IMG_SIZE   = (224, 224)
BATCH_SIZE = 32


# ══════════════════════════════════════════════════════════════════════════════
#  Helpers
# ══════════════════════════════════════════════════════════════════════════════

def load_model(seed_type: str):
    import tensorflow as tf
    model_path = MODELS_DIR / f"{seed_type}_grade_model.keras"
    if not model_path.exists():
        log.error(f"[{seed_type}] Model not found: {model_path}")
        log.error(f"  Run first:  python services/train_model.py --seed_type {seed_type}")
        return None
    log.info(f"[{seed_type}] Loading model from {model_path} …")
    return tf.keras.models.load_model(str(model_path))


def build_validation_generator(seed_type: str):
    """Build a validation-only generator (no shuffle, no augmentation)."""
    from tensorflow.keras.preprocessing.image import ImageDataGenerator

    seed_dir = str(DATASET_DIR / seed_type)
    gen = ImageDataGenerator(rescale=1.0 / 255, validation_split=0.20)
    val_ds = gen.flow_from_directory(
        seed_dir,
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="categorical",
        classes=GRADES,
        subset="validation",
        shuffle=False,
        seed=42,
    )
    return val_ds


def plot_confusion_matrix(cm: np.ndarray, seed_type: str):
    """Save a styled confusion matrix as PNG."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(7, 6))
        im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
        fig.colorbar(im, ax=ax)

        ax.set(
            xticks=range(3),
            yticks=range(3),
            xticklabels=GRADES,
            yticklabels=GRADES,
            title=f"SeedSense — {seed_type.title()} Confusion Matrix",
            ylabel="True Grade",
            xlabel="Predicted Grade",
        )

        total = cm.sum()
        for i in range(3):
            for j in range(3):
                count = cm[i, j]
                pct   = count / total * 100 if total > 0 else 0
                color = "white" if cm[i, j] > cm.max() / 2 else "black"
                ax.text(j, i, f"{count}\n({pct:.1f}%)",
                        ha="center", va="center", color=color, fontsize=10)

        plt.tight_layout()
        out = REPORTS_DIR / f"{seed_type}_confusion_matrix.png"
        plt.savefig(str(out), dpi=120, bbox_inches="tight")
        plt.close()
        log.info(f"[{seed_type}] Confusion matrix → {out}")
    except Exception as exc:
        log.warning(f"[{seed_type}] Could not plot confusion matrix: {exc}")


def plot_learning_curves(seed_type: str):
    """Re-plot learning curves from saved history JSON."""
    hist_path = REPORTS_DIR / f"{seed_type}_history.json"
    if not hist_path.exists():
        log.warning(f"[{seed_type}] No history file found at {hist_path} — skipping curve plot")
        return
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        with open(hist_path) as f:
            h = json.load(f)

        epochs = range(1, len(h.get("accuracy", [])) + 1)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
        fig.suptitle(f"SeedSense — {seed_type.title()} Learning Curves", fontsize=14, fontweight="bold")

        ax1.plot(epochs, h.get("accuracy",     []), "b-o", markersize=4, label="Train")
        ax1.plot(epochs, h.get("val_accuracy", []), "r-o", markersize=4, label="Validation")
        ax1.set_title("Accuracy"); ax1.set_xlabel("Epoch"); ax1.set_ylabel("Accuracy")
        ax1.legend(); ax1.grid(alpha=0.3)

        ax2.plot(epochs, h.get("loss",     []), "b-o", markersize=4, label="Train")
        ax2.plot(epochs, h.get("val_loss", []), "r-o", markersize=4, label="Validation")
        ax2.set_title("Loss"); ax2.set_xlabel("Epoch"); ax2.set_ylabel("Loss")
        ax2.legend(); ax2.grid(alpha=0.3)

        plt.tight_layout()
        out = REPORTS_DIR / f"{seed_type}_accuracy_curve.png"
        plt.savefig(str(out), dpi=120, bbox_inches="tight")
        plt.close()
        log.info(f"[{seed_type}] Learning curves → {out}")
    except Exception as exc:
        log.warning(f"[{seed_type}] Could not plot curves: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
#  Main evaluation function
# ══════════════════════════════════════════════════════════════════════════════

def evaluate(seed_type: str):
    log.info(f"{'='*60}")
    log.info(f"  Evaluating: {seed_type.upper()}")
    log.info(f"{'='*60}")

    model = load_model(seed_type)
    if model is None:
        return

    val_ds = build_validation_generator(seed_type)
    if len(val_ds) == 0:
        log.error(f"[{seed_type}] Validation dataset is empty — run dataset_builder first")
        return

    # ── Predictions ───────────────────────────────────────────────────────────
    log.info(f"[{seed_type}] Running predictions on {val_ds.samples} validation images …")
    y_pred_probs = model.predict(val_ds, verbose=1)
    y_pred = np.argmax(y_pred_probs, axis=1)
    y_true = val_ds.classes

    # ── Scikit-learn metrics ──────────────────────────────────────────────────
    from sklearn.metrics import (
        classification_report, confusion_matrix,
        accuracy_score, precision_score, recall_score, f1_score,
    )

    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average="weighted", zero_division=0)
    rec  = recall_score(y_true, y_pred, average="weighted", zero_division=0)
    f1   = f1_score(y_true, y_pred, average="weighted", zero_division=0)
    cm   = confusion_matrix(y_true, y_pred)
    report = classification_report(y_true, y_pred, target_names=GRADES, output_dict=True)

    log.info(f"\n[{seed_type}] ── Classification Report ─────────────────────────")
    log.info(f"  Accuracy  : {acc:.4f}")
    log.info(f"  Precision : {prec:.4f}")
    log.info(f"  Recall    : {rec:.4f}")
    log.info(f"  F1-Score  : {f1:.4f}")
    log.info(f"\n  Confusion Matrix:\n{cm}")
    log.info(classification_report(y_true, y_pred, target_names=GRADES))

    # ── Save metrics JSON ─────────────────────────────────────────────────────
    metrics = {
        "seed_type": seed_type,
        "samples_evaluated": int(val_ds.samples),
        "accuracy":  round(float(acc),  4),
        "precision": round(float(prec), 4),
        "recall":    round(float(rec),  4),
        "f1_score":  round(float(f1),   4),
        "per_class": {
            g: {
                "precision": round(report[g]["precision"], 4),
                "recall":    round(report[g]["recall"],    4),
                "f1-score":  round(report[g]["f1-score"],  4),
                "support":   int(report[g]["support"]),
            }
            for g in GRADES if g in report
        },
        "confusion_matrix": cm.tolist(),
    }

    metrics_path = REPORTS_DIR / f"{seed_type}_metrics.json"
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)
    log.info(f"[{seed_type}] Metrics saved → {metrics_path}")

    # ── Plots ─────────────────────────────────────────────────────────────────
    plot_confusion_matrix(cm, seed_type)
    plot_learning_curves(seed_type)

    log.info(f"[{seed_type}] Evaluation COMPLETE ✓")


# ══════════════════════════════════════════════════════════════════════════════
#  CLI entry point
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="SeedSense Model Evaluator")
    parser.add_argument(
        "--seed_type", default="all",
        choices=SEED_TYPES + ["all"],
        help="Seed type to evaluate (default: all)"
    )
    args = parser.parse_args()

    types_to_eval = SEED_TYPES if args.seed_type == "all" else [args.seed_type]

    for stype in types_to_eval:
        try:
            evaluate(stype)
        except Exception as exc:
            log.error(f"[{stype}] Evaluation FAILED: {exc}")
            import traceback; traceback.print_exc()

    log.info("\nAll evaluations done. Check training_reports/ for charts and metrics.")
    log.info("Start the app:  python app.py")


if __name__ == "__main__":
    main()
