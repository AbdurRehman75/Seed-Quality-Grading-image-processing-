"""
SeedSense — ML Predictor
=========================
University of Agriculture Faisalabad · BS Software Engineering FYP 2026

Thread-safe model cache.  Called by Flask app.py after OpenCV analysis.

Public API:
  predict_grade(img_bgr, seed_type) -> dict | None

Returns:
  {
    "grade":       "A" | "B" | "C",
    "confidence":  float,            # 0.0 – 1.0  (probability of predicted class)
    "predictions": {"A": float, "B": float, "C": float},
    "source":      "CNN"
  }
  or None if model is not available for this seed_type.
"""

import os
import threading
import logging
from pathlib import Path

import cv2
import numpy as np

log = logging.getLogger("ml_predictor")

# ── Paths ──────────────────────────────────────────────────────────────────────
APP_DIR    = Path(__file__).resolve().parent.parent
MODELS_DIR = APP_DIR / "models"

SEED_TYPES = ["wheat", "rice", "corn"]
GRADES     = ["A", "B", "C"]
IMG_SIZE   = (224, 224)

# ── Thread-safe model cache ────────────────────────────────────────────────────
_lock   = threading.Lock()
_cache: dict[str, object] = {}   # seed_type → keras model | "MISSING"


def _load_model(seed_type: str):
    """Load (or recall cached) Keras model for given seed_type."""
    with _lock:
        if seed_type in _cache:
            return _cache[seed_type]

        model_path = MODELS_DIR / f"{seed_type}_grade_model.keras"
        if not model_path.exists():
            log.info(f"[ml_predictor] No model found for '{seed_type}' — CNN will be skipped")
            _cache[seed_type] = "MISSING"
            return "MISSING"

        try:
            # Import TF lazily so the app starts fast when TF is not installed
            import tensorflow as tf  # noqa: F401
            model = tf.keras.models.load_model(str(model_path))
            _cache[seed_type] = model
            log.info(f"[ml_predictor] Loaded model: {model_path}")
            return model
        except Exception as exc:
            log.error(f"[ml_predictor] Failed to load model for '{seed_type}': {exc}")
            _cache[seed_type] = "MISSING"
            return "MISSING"


def _preprocess(img_bgr: np.ndarray) -> np.ndarray:
    """Resize and normalise a BGR image for MobileNetV2 input."""
    img_rgb  = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    img_resized = cv2.resize(img_rgb, IMG_SIZE, interpolation=cv2.INTER_AREA)
    img_float   = img_resized.astype(np.float32) / 255.0
    return np.expand_dims(img_float, axis=0)   # shape (1, 224, 224, 3)


# ══════════════════════════════════════════════════════════════════════════════
#  Public API
# ══════════════════════════════════════════════════════════════════════════════

def predict_grade(img_bgr: np.ndarray, seed_type: str) -> dict | None:
    """
    Run CNN inference on a BGR image.

    Parameters
    ----------
    img_bgr   : OpenCV BGR image (numpy array)
    seed_type : "wheat" | "rice" | "corn"

    Returns
    -------
    dict with keys: grade, confidence, predictions, source
    None if model is unavailable.
    """
    if seed_type not in SEED_TYPES:
        seed_type = "wheat"

    model = _load_model(seed_type)
    if model == "MISSING":
        return None

    try:
        x     = _preprocess(img_bgr)
        probs = model.predict(x, verbose=0)[0]          # shape (3,)

        idx        = int(np.argmax(probs))
        grade      = GRADES[idx]
        confidence = float(probs[idx])

        predictions = {g: round(float(p), 4) for g, p in zip(GRADES, probs)}

        return {
            "grade":       grade,
            "confidence":  round(confidence, 4),
            "predictions": predictions,
            "source":      "CNN",
        }

    except Exception as exc:
        log.error(f"[ml_predictor] Prediction error for '{seed_type}': {exc}")
        return None


def model_exists(seed_type: str) -> bool:
    """Quick check — does a trained model file exist for this seed type?"""
    return (MODELS_DIR / f"{seed_type}_grade_model.keras").exists()


def clear_cache():
    """Force-reload all models on next prediction (useful after retraining)."""
    with _lock:
        _cache.clear()
    log.info("[ml_predictor] Model cache cleared")
