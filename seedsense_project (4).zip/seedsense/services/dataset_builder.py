"""
SeedSense — Automated Dataset Builder
======================================
University of Agriculture Faisalabad · BS Software Engineering FYP 2026

Pipeline:
  1. Try Kaggle API download → fall back to raw_datasets/ → fall back to mock generation
  2. Scan all images, remove corrupt files
  3. Map folder-name labels → Grade A/B/C  (keyword matching)
  4. For unlabeled/variety datasets → OpenCV quality scoring → auto-assign grade
  5. Balance classes via augmentation up to --min_per_class
  6. Write dataset/ tree + dataset_summary.json

Usage:
  python services/dataset_builder.py --seed_type all --min_per_class 300
"""

import os
import sys
import json
import shutil
import random
import argparse
import logging
import traceback
from pathlib import Path

import cv2
import numpy as np

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("dataset_builder")

# ── Paths ─────────────────────────────────────────────────────────────────────
APP_DIR     = Path(__file__).resolve().parent.parent
RAW_DIR     = APP_DIR / "raw_datasets"
DATASET_DIR = APP_DIR / "dataset"
SUMMARY_PATH = APP_DIR / "dataset_summary.json"

SEED_TYPES = ["wheat", "rice", "corn"]
GRADES     = ["A", "B", "C"]

# ── Label keyword mappings ────────────────────────────────────────────────────
GRADE_A_KEYWORDS = {"healthy", "good", "normal", "premium", "grade_a", "gradea", "high", "clean", "sound"}
GRADE_B_KEYWORDS = {"minor", "medium", "mixed", "average", "moderate", "grade_b", "gradeb", "fair", "slight"}
GRADE_C_KEYWORDS = {"damaged", "broken", "pest", "infected", "bad", "poor", "diseased", "mold",
                    "rot", "crack", "shriveled", "grade_c", "gradec", "discolored", "fungal"}

# ── Kaggle dataset identifiers (best public options) ─────────────────────────
KAGGLE_DATASETS = {
    "wheat": "muratkokludataset/wheat-disease-detection",
    "rice":  "muratkokludataset/rice-image-dataset",
    "corn":  "muratkokludataset/corn-maize-leaf-disease-dataset",
}

# ── Seed visual profiles (for OpenCV auto-grading) ───────────────────────────
SEED_PROFILES = {
    "wheat": {
        "aspect_ideal": (2.2, 4.8),
        "color_hsv_low":  np.array([8,  25,  60]),
        "color_hsv_high": np.array([38, 220, 240]),
        "texture_thresh": 1200.0,
    },
    "rice": {
        "aspect_ideal": (2.8, 6.5),
        "color_hsv_low":  np.array([12,  8, 130]),
        "color_hsv_high": np.array([42, 130, 255]),
        "texture_thresh": 800.0,
    },
    "corn": {
        "aspect_ideal": (0.9, 2.4),
        "color_hsv_low":  np.array([12, 70,  90]),
        "color_hsv_high": np.array([42, 255, 255]),
        "texture_thresh": 1800.0,
    },
}


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 1 — Image acquisition
# ══════════════════════════════════════════════════════════════════════════════

def try_kaggle_download(seed_type: str) -> bool:
    """Attempt to download a dataset from Kaggle. Returns True on success."""
    try:
        import kaggle  # noqa: F401 — presence check
        dataset_id = KAGGLE_DATASETS.get(seed_type)
        if not dataset_id:
            return False
        dest = RAW_DIR / seed_type
        dest.mkdir(parents=True, exist_ok=True)
        log.info(f"[{seed_type}] Downloading Kaggle dataset: {dataset_id}")
        os.system(
            f'kaggle datasets download -d "{dataset_id}" '
            f'--unzip -p "{dest}" --quiet'
        )
        # Check something was actually written
        imgs = list(dest.rglob("*.jpg")) + list(dest.rglob("*.png"))
        if imgs:
            log.info(f"[{seed_type}] Kaggle download OK — {len(imgs)} images")
            return True
        log.warning(f"[{seed_type}] Kaggle download produced no images")
        return False
    except Exception as exc:
        log.info(f"[{seed_type}] Kaggle unavailable ({exc}). Using local/mock data.")
        return False


def generate_mock_images(seed_type: str, count_per_grade: int = 50):
    """
    Generate realistic synthetic seed images using OpenCV when no real
    dataset is available. Useful for offline / CI environments.
    """
    log.info(f"[{seed_type}] Generating {count_per_grade * 3} mock images …")
    profile = SEED_PROFILES.get(seed_type, SEED_PROFILES["wheat"])
    base_dest = RAW_DIR / seed_type

    grade_configs = {
        "A": {"noise": 5,  "brightness": (210, 240), "defect_prob": 0.02},
        "B": {"noise": 18, "brightness": (160, 200), "defect_prob": 0.15},
        "C": {"noise": 40, "brightness": (80,  150), "defect_prob": 0.40},
    }

    # Base seed colors by type
    seed_colors = {
        "wheat": {"A": (45, 130, 190), "B": (35, 110, 160), "C": (25, 80, 120)},
        "rice":  {"A": (80, 190, 220), "B": (70, 170, 200), "C": (60, 140, 170)},
        "corn":  {"A": (30, 160, 220), "B": (25, 130, 190), "C": (20, 100, 150)},
    }[seed_type]

    for grade, cfg in grade_configs.items():
        dest = base_dest / grade
        dest.mkdir(parents=True, exist_ok=True)
        for i in range(count_per_grade):
            img = np.ones((224, 224, 3), dtype=np.uint8) * 245  # white bg
            num_seeds = random.randint(8, 20)
            for _ in range(num_seeds):
                cx = random.randint(20, 204)
                cy = random.randint(20, 204)
                # Ellipse for seed shape
                lo, hi = profile["aspect_ideal"]
                aspect = random.uniform(lo, hi)
                rx = random.randint(8, 18)
                ry = max(4, int(rx * aspect / 2))
                angle = random.randint(0, 180)
                color = tuple(
                    int(c + random.gauss(0, 12)) for c in seed_colors[grade]
                )
                color = tuple(np.clip(color, 0, 255))
                cv2.ellipse(img, (cx, cy), (rx, ry), angle, 0, 360, color, -1)
                # Add defects to B/C
                if random.random() < cfg["defect_prob"]:
                    dx = cx + random.randint(-rx, rx)
                    dy = cy + random.randint(-ry, ry)
                    cv2.circle(img, (dx, dy), random.randint(2, 5), (30, 30, 80), -1)

            # Global noise
            noise = np.random.randint(-cfg["noise"], cfg["noise"] + 1,
                                      img.shape, dtype=np.int16)
            img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
            cv2.imwrite(str(dest / f"mock_{grade}_{i:04d}.jpg"), img,
                        [cv2.IMWRITE_JPEG_QUALITY, 90])

    log.info(f"[{seed_type}] Mock generation complete")


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 2 — Scan & validate images
# ══════════════════════════════════════════════════════════════════════════════

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tiff", ".tif"}


def collect_images(root: Path) -> list[Path]:
    """Recursively collect all image paths under root."""
    paths = []
    for ext in IMAGE_EXTENSIONS:
        paths.extend(root.rglob(f"*{ext}"))
        paths.extend(root.rglob(f"*{ext.upper()}"))
    return paths


def is_valid_image(path: Path) -> bool:
    """Return True if the file is a readable, non-corrupt image."""
    try:
        img = cv2.imread(str(path))
        if img is None or img.size == 0:
            return False
        h, w = img.shape[:2]
        return h >= 32 and w >= 32
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 3 — Label inference from folder/file names
# ══════════════════════════════════════════════════════════════════════════════

def infer_grade_from_path(path: Path) -> str | None:
    """
    Check folder and filename tokens against grade keyword lists.
    Returns 'A', 'B', 'C', or None if no match found.
    """
    tokens = set(
        t.lower()
        for part in path.parts
        for t in part.replace("-", "_").replace(" ", "_").split("_")
    )
    if tokens & GRADE_A_KEYWORDS:
        return "A"
    if tokens & GRADE_B_KEYWORDS:
        return "B"
    if tokens & GRADE_C_KEYWORDS:
        return "C"
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 4 — OpenCV quality scoring (fallback auto-labeler)
# ══════════════════════════════════════════════════════════════════════════════

def opencv_quality_score(img_bgr: np.ndarray, seed_type: str) -> float:
    """
    Returns a defect score in [0, 1].
      < 0.22 → Grade A
      < 0.45 → Grade B
      >= 0.45 → Grade C
    """
    profile = SEED_PROFILES.get(seed_type, SEED_PROFILES["wheat"])
    gray    = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    blur    = cv2.GaussianBlur(gray, (7, 7), 0)
    _, thr  = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    kernel  = np.ones((3, 3), np.uint8)
    thr     = cv2.morphologyEx(thr, cv2.MORPH_OPEN,  kernel, iterations=2)
    thr     = cv2.morphologyEx(thr, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(thr, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w  = img_bgr.shape[:2]
    min_area = max(150, int(h * w * 0.00002))
    kernels  = [c for c in contours if cv2.contourArea(c) >= min_area]

    if not kernels:
        return 0.7  # no seeds detected → poor quality

    shape_scores, color_scores, texture_scores = [], [], []
    for c in kernels:
        x, y, bw, bh = cv2.boundingRect(c)
        roi_bgr  = img_bgr[max(0, y):y + bh, max(0, x):x + bw]
        roi_gray = gray[max(0, y):y + bh, max(0, x):x + bw]

        # Shape
        area      = cv2.contourArea(c)
        perimeter = cv2.arcLength(c, True)
        if perimeter == 0:
            continue
        circularity = (4 * np.pi * area) / (perimeter ** 2 + 1e-9)
        ax, ay, abw, abh = cv2.boundingRect(c)
        aspect = max(abw, abh) / (min(abw, abh) + 1e-9)
        lo, hi = profile["aspect_ideal"]
        aspect_dev = 0.0 if lo <= aspect <= hi else min(1.0, abs(aspect - (lo + hi) / 2) * 0.3)
        shape_scores.append(float(np.clip(aspect_dev + max(0, 0.55 - circularity), 0, 1)))

        # Color
        if roi_bgr.size > 0:
            hsv  = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, profile["color_hsv_low"], profile["color_hsv_high"])
            in_range = np.count_nonzero(mask) / max(1, mask.size)
            color_scores.append(float(np.clip(1.0 - in_range, 0, 1)))

        # Texture
        if roi_gray.size > 0:
            lap = cv2.Laplacian(roi_gray, cv2.CV_64F)
            score = float(np.clip(lap.var() / profile["texture_thresh"], 0, 1))
            texture_scores.append(score)

    s = float(np.mean(shape_scores))   if shape_scores   else 0.5
    c = float(np.mean(color_scores))   if color_scores   else 0.5
    t = float(np.mean(texture_scores)) if texture_scores else 0.5

    return float(np.clip(s * 0.40 + c * 0.35 + t * 0.25, 0, 1))


def auto_grade_by_opencv(img_path: Path, seed_type: str) -> str:
    img = cv2.imread(str(img_path))
    if img is None:
        return "C"
    score = opencv_quality_score(img, seed_type)
    if score < 0.22:
        return "A"
    elif score < 0.45:
        return "B"
    else:
        return "C"


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 5 — Augmentation helpers
# ══════════════════════════════════════════════════════════════════════════════

def augment_image(img: np.ndarray) -> np.ndarray:
    """Apply random augmentations: flip, rotate, brightness, contrast, noise."""
    # Random horizontal flip
    if random.random() > 0.5:
        img = cv2.flip(img, 1)
    # Random vertical flip
    if random.random() > 0.7:
        img = cv2.flip(img, 0)
    # Random rotation ±20°
    angle = random.uniform(-20, 20)
    h, w  = img.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    img = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    # Brightness & contrast jitter
    alpha = random.uniform(0.75, 1.30)
    beta  = random.randint(-30, 30)
    img   = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)
    # Gaussian noise
    noise = np.random.normal(0, random.uniform(0, 10), img.shape).astype(np.int16)
    img   = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    return img


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN build function
# ══════════════════════════════════════════════════════════════════════════════

def build_dataset(seed_type: str, min_per_class: int = 300):
    log.info(f"{'='*60}")
    log.info(f"  Building dataset: {seed_type.upper()}  (min {min_per_class}/class)")
    log.info(f"{'='*60}")

    raw_seed_dir = RAW_DIR / seed_type

    # ── Acquire raw images ────────────────────────────────────────────────────
    has_raw = raw_seed_dir.exists() and len(collect_images(raw_seed_dir)) > 0
    if not has_raw:
        downloaded = try_kaggle_download(seed_type)
        if not downloaded:
            generate_mock_images(seed_type, count_per_grade=max(50, min_per_class // 3))

    # ── Scan & validate ───────────────────────────────────────────────────────
    all_images = collect_images(raw_seed_dir)
    log.info(f"[{seed_type}] Found {len(all_images)} raw image files — validating …")

    valid_images = []
    for p in all_images:
        if is_valid_image(p):
            valid_images.append(p)
        else:
            log.debug(f"  Corrupt/unreadable: {p}")
    log.info(f"[{seed_type}] {len(valid_images)} valid images after corruption check")

    # ── Label each image ──────────────────────────────────────────────────────
    buckets: dict[str, list[Path]] = {"A": [], "B": [], "C": []}
    for p in valid_images:
        grade = infer_grade_from_path(p)
        if grade is None:
            grade = auto_grade_by_opencv(p, seed_type)
        buckets[grade].append(p)

    for g in GRADES:
        log.info(f"[{seed_type}] Grade {g}: {len(buckets[g])} images (before augmentation)")

    # ── Copy originals into dataset/ tree ────────────────────────────────────
    dest_dirs = {}
    for g in GRADES:
        d = DATASET_DIR / seed_type / g
        d.mkdir(parents=True, exist_ok=True)
        dest_dirs[g] = d

    # Clear previous dataset for this seed type to avoid stale data
    for g in GRADES:
        for f in dest_dirs[g].iterdir():
            f.unlink(missing_ok=True)

    for g, paths in buckets.items():
        for idx, src in enumerate(paths):
            ext  = src.suffix.lower() or ".jpg"
            dest = dest_dirs[g] / f"{seed_type}_{g}_{idx:05d}{ext}"
            shutil.copy2(src, dest)

    # ── Balance via augmentation ──────────────────────────────────────────────
    for g in GRADES:
        existing = list(dest_dirs[g].glob("*"))
        current  = len(existing)
        needed   = max(0, min_per_class - current)
        if needed == 0:
            log.info(f"[{seed_type}] Grade {g}: {current} images — no augmentation needed")
            continue
        log.info(f"[{seed_type}] Grade {g}: augmenting {current} → {current + needed} images")
        aug_idx = current
        while needed > 0:
            src_path = random.choice(existing)
            img = cv2.imread(str(src_path))
            if img is None:
                continue
            img = augment_image(img)
            aug_path = dest_dirs[g] / f"{seed_type}_{g}_aug_{aug_idx:05d}.jpg"
            cv2.imwrite(str(aug_path), img, [cv2.IMWRITE_JPEG_QUALITY, 88])
            aug_idx += 1
            needed  -= 1

    # ── Final counts ──────────────────────────────────────────────────────────
    final_counts = {}
    for g in GRADES:
        count = len(list(dest_dirs[g].glob("*")))
        final_counts[g] = count
        log.info(f"[{seed_type}] Grade {g}: {count} images (final)")

    return final_counts


# ══════════════════════════════════════════════════════════════════════════════
#  CLI entry point
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="SeedSense Dataset Builder")
    parser.add_argument(
        "--seed_type", default="all",
        choices=SEED_TYPES + ["all"],
        help="Seed type to process (default: all)"
    )
    parser.add_argument(
        "--min_per_class", type=int, default=300,
        help="Minimum images per grade class after augmentation (default: 300)"
    )
    args = parser.parse_args()

    types_to_process = SEED_TYPES if args.seed_type == "all" else [args.seed_type]

    summary = {
        "status": "In Progress",
        "min_per_class": args.min_per_class,
        "warning": (
            "Automated labeling is approximate. For scientific-grade accuracy, "
            "dataset labels should be reviewed by an agricultural expert."
        ),
        "details": {},
    }

    for stype in types_to_process:
        try:
            counts = build_dataset(stype, args.min_per_class)
            summary["details"][stype] = counts
        except Exception as exc:
            log.error(f"[{stype}] FAILED: {exc}")
            log.debug(traceback.format_exc())
            summary["details"][stype] = {"error": str(exc)}

    summary["status"] = "Completed"

    with open(SUMMARY_PATH, "w") as f:
        json.dump(summary, f, indent=4)
    log.info(f"\nDataset summary written → {SUMMARY_PATH}")
    log.info("Dataset preparation complete. Next step:")
    log.info("  python services/train_model.py --seed_type all --epochs 25")


if __name__ == "__main__":
    main()
