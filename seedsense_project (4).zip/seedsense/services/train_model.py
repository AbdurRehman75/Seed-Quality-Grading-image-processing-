"""
SeedSense — CNN Model Trainer
==============================
University of Agriculture Faisalabad · BS Software Engineering FYP 2026

Architecture:
  MobileNetV2 (ImageNet weights) → GlobalAveragePooling2D → Dense(256) → Dropout → Dense(3, softmax)
  Fine-tuning: last 20 layers of MobileNetV2 unfrozen in phase 2

Usage:
  python services/train_model.py --seed_type all --epochs 25
"""

import os
import sys
import json
import argparse
import logging
from pathlib import Path

import numpy as np

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("train_model")

# ── Paths ──────────────────────────────────────────────────────────────────────
APP_DIR      = Path(__file__).resolve().parent.parent
DATASET_DIR  = APP_DIR / "dataset"
MODELS_DIR   = APP_DIR / "models"
REPORTS_DIR  = APP_DIR / "training_reports"

MODELS_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)

SEED_TYPES = ["wheat", "rice", "corn"]
GRADES     = ["A", "B", "C"]
IMG_SIZE   = (224, 224)
BATCH_SIZE = 32


# ══════════════════════════════════════════════════════════════════════════════
#  Helpers
# ══════════════════════════════════════════════════════════════════════════════

def check_dataset(seed_type: str) -> bool:
    for g in GRADES:
        p = DATASET_DIR / seed_type / g
        if not p.exists() or len(list(p.glob("*"))) == 0:
            log.error(
                f"[{seed_type}] Missing or empty dataset folder: {p}\n"
                f"  Run first:  python services/dataset_builder.py --seed_type {seed_type}"
            )
            return False
    return True


def build_generators(seed_type: str):
    """Build Keras ImageDataGenerators for train and validation splits."""
    import tensorflow as tf
    from tensorflow.keras.preprocessing.image import ImageDataGenerator  # type: ignore

    seed_dir = str(DATASET_DIR / seed_type)

    train_gen = ImageDataGenerator(
        rescale=1.0 / 255,
        validation_split=0.20,
        rotation_range=25,
        width_shift_range=0.15,
        height_shift_range=0.15,
        shear_range=0.10,
        zoom_range=0.20,
        brightness_range=[0.7, 1.3],
        horizontal_flip=True,
        vertical_flip=True,
        fill_mode="reflect",
    )

    train_ds = train_gen.flow_from_directory(
        seed_dir,
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="categorical",
        classes=GRADES,
        subset="training",
        seed=42,
    )

    val_ds = train_gen.flow_from_directory(
        seed_dir,
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="categorical",
        classes=GRADES,
        subset="validation",
        seed=42,
    )

    return train_ds, val_ds


def build_model() -> "tf.keras.Model":
    """Build MobileNetV2 transfer learning model."""
    import tensorflow as tf
    from tensorflow.keras.applications import MobileNetV2
    from tensorflow.keras.layers import (
        GlobalAveragePooling2D, Dense, Dropout, BatchNormalization
    )
    from tensorflow.keras.models import Model

    base = MobileNetV2(
        input_shape=(*IMG_SIZE, 3),
        include_top=False,
        weights="imagenet",
    )
    base.trainable = False  # freeze all base layers initially

    x = base.output
    x = GlobalAveragePooling2D()(x)
    x = BatchNormalization()(x)
    x = Dense(256, activation="relu")(x)
    x = Dropout(0.40)(x)
    x = Dense(128, activation="relu")(x)
    x = Dropout(0.30)(x)
    output = Dense(3, activation="softmax")(x)

    model = Model(inputs=base.input, outputs=output)
    return model, base


def get_callbacks(seed_type: str, model_path: str) -> list:
    import tensorflow as tf

    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_accuracy",
            patience=6,
            restore_best_weights=True,
            verbose=1,
        ),
        tf.keras.callbacks.ModelCheckpoint(
            filepath=model_path,
            monitor="val_accuracy",
            save_best_only=True,
            verbose=1,
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.4,
            patience=3,
            min_lr=1e-7,
            verbose=1,
        ),
        tf.keras.callbacks.TensorBoard(
            log_dir=str(REPORTS_DIR / f"tb_{seed_type}"),
            histogram_freq=0,
        ),
    ]
    return callbacks


def save_history(history_obj, seed_type: str):
    """Save training history as JSON for later analysis."""
    hist_path = REPORTS_DIR / f"{seed_type}_history.json"
    hist = {k: [float(v) for v in vals] for k, vals in history_obj.history.items()}
    with open(hist_path, "w") as f:
        json.dump(hist, f, indent=2)
    log.info(f"[{seed_type}] Training history saved → {hist_path}")


def plot_history(history_obj, seed_type: str):
    """Plot and save accuracy/loss learning curves."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        h = history_obj.history
        epochs = range(1, len(h["accuracy"]) + 1)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
        fig.suptitle(f"SeedSense — {seed_type.title()} Training Curves", fontsize=14, fontweight="bold")

        # Accuracy
        ax1.plot(epochs, h["accuracy"],     "b-o", markersize=4, label="Train Acc")
        ax1.plot(epochs, h["val_accuracy"], "r-o", markersize=4, label="Val Acc")
        ax1.set_title("Model Accuracy")
        ax1.set_xlabel("Epoch")
        ax1.set_ylabel("Accuracy")
        ax1.legend()
        ax1.grid(alpha=0.3)

        # Loss
        ax2.plot(epochs, h["loss"],     "b-o", markersize=4, label="Train Loss")
        ax2.plot(epochs, h["val_loss"], "r-o", markersize=4, label="Val Loss")
        ax2.set_title("Model Loss")
        ax2.set_xlabel("Epoch")
        ax2.set_ylabel("Loss")
        ax2.legend()
        ax2.grid(alpha=0.3)

        plt.tight_layout()
        out = REPORTS_DIR / f"{seed_type}_accuracy_curve.png"
        plt.savefig(str(out), dpi=120, bbox_inches="tight")
        plt.close()
        log.info(f"[{seed_type}] Learning curve saved → {out}")
    except Exception as exc:
        log.warning(f"[{seed_type}] Could not plot history: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
#  Main training function
# ══════════════════════════════════════════════════════════════════════════════

def train(seed_type: str, epochs: int = 25):
    log.info(f"{'='*60}")
    log.info(f"  Training: {seed_type.upper()}  ({epochs} epochs)")
    log.info(f"{'='*60}")

    if not check_dataset(seed_type):
        return False

    import tensorflow as tf
    log.info(f"TensorFlow version: {tf.__version__}")
    gpus = tf.config.list_physical_devices("GPU")
    log.info(f"GPUs available: {len(gpus)}")

    # ── Data ──────────────────────────────────────────────────────────────────
    train_ds, val_ds = build_generators(seed_type)
    log.info(f"[{seed_type}] Train batches: {len(train_ds)} | Val batches: {len(val_ds)}")
    log.info(f"[{seed_type}] Class indices: {train_ds.class_indices}")

    # ── Model ─────────────────────────────────────────────────────────────────
    model, base_model = build_model()
    model_path = str(MODELS_DIR / f"{seed_type}_grade_model.keras")
    labels_path = MODELS_DIR / f"{seed_type}_labels.json"

    # Save label mapping
    with open(labels_path, "w") as f:
        json.dump(train_ds.class_indices, f, indent=2)
    log.info(f"[{seed_type}] Labels saved → {labels_path}")

    # ── Phase 1: Train classification head only ───────────────────────────────
    log.info(f"[{seed_type}] Phase 1: Training classification head …")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    model.summary(print_fn=lambda x: log.debug(x))

    phase1_epochs = min(epochs // 2 + 1, 15)
    history1 = model.fit(
        train_ds,
        epochs=phase1_epochs,
        validation_data=val_ds,
        callbacks=get_callbacks(seed_type, model_path),
        verbose=1,
    )
    log.info(f"[{seed_type}] Phase 1 complete — best val_accuracy: "
             f"{max(history1.history.get('val_accuracy', [0])):.4f}")

    # ── Phase 2: Fine-tune last 20 layers ────────────────────────────────────
    log.info(f"[{seed_type}] Phase 2: Fine-tuning last 20 base layers …")
    base_model.trainable = True
    for layer in base_model.layers[:-20]:
        layer.trainable = False

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-5),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )

    remaining_epochs = max(epochs - phase1_epochs, 5)
    history2 = model.fit(
        train_ds,
        epochs=remaining_epochs,
        validation_data=val_ds,
        callbacks=get_callbacks(seed_type, model_path),
        verbose=1,
    )
    log.info(f"[{seed_type}] Phase 2 complete — best val_accuracy: "
             f"{max(history2.history.get('val_accuracy', [0])):.4f}")

    # ── Merge histories & save ────────────────────────────────────────────────
    merged_history = type("History", (), {"history": {}})()
    for key in history1.history:
        merged_history.history[key] = (
            history1.history.get(key, []) + history2.history.get(key, [])
        )

    save_history(merged_history, seed_type)
    plot_history(merged_history, seed_type)

    # Ensure final model is saved (checkpoint may have best weights already)
    if not os.path.exists(model_path):
        model.save(model_path)
    log.info(f"[{seed_type}] Model saved → {model_path}")
    log.info(f"[{seed_type}] Training COMPLETE ✓")
    return True


# ══════════════════════════════════════════════════════════════════════════════
#  CLI entry point
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="SeedSense CNN Model Trainer")
    parser.add_argument(
        "--seed_type", default="all",
        choices=SEED_TYPES + ["all"],
        help="Seed type to train (default: all)"
    )
    parser.add_argument(
        "--epochs", type=int, default=25,
        help="Total training epochs across both phases (default: 25)"
    )
    args = parser.parse_args()

    types_to_train = SEED_TYPES if args.seed_type == "all" else [args.seed_type]

    results = {}
    for stype in types_to_train:
        try:
            ok = train(stype, args.epochs)
            results[stype] = "success" if ok else "skipped (missing dataset)"
        except Exception as exc:
            log.error(f"[{stype}] Training FAILED: {exc}")
            import traceback; traceback.print_exc()
            results[stype] = f"error: {exc}"

    log.info("\n── Training Summary ─────────────────────────────────────────")
    for stype, status in results.items():
        log.info(f"  {stype:8s}  {status}")
    log.info("\nNext step:")
    log.info("  python services/evaluate_model.py --seed_type all")


if __name__ == "__main__":
    main()
